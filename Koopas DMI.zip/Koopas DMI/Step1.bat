BiosConfigUtility.exe /get:"CT.txt"
