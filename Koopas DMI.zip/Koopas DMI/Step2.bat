BiosConfigUtility.exe /set:"CT.txt"
del CT.txt